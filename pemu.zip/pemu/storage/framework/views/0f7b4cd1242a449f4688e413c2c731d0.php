<?php if (isset($component)) { $__componentOriginal00946ba7ba842207a1e069667fe21ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00946ba7ba842207a1e069667fe21ffc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.adminlayout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">View PEMU  Blogs </h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">View</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Blogs</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-9 col-lg-12 col-md-6 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header">All Blogs</h5>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="bg-light">
                                    <tr class="border-0">
                                        <th class="border-0">#</th>
                                        <th class="border-0">Image</th>
                                        <th class="border-0">Blog Title</th>
                                        <th class="border-0">Views</th>
                                        <th class="border-0">Likes</th>
                                        <th class="border-0">Dislikes</th>
                                        <th class="border-0">Shares</th>
                                        <th class="border-0">Date Created</th>
                                        <th class="border-0">Author</th>
                                        <th class="border-0">Status</th>
                                        
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (! (count($blogs) == 0)): ?>
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($blog->id); ?></td>
                                        <td>
                                            <div class="m-r-10"><img src="<?php echo e($blog->image ? asset('storage/' . $blog->image) : asset('Admin/assets/images/product-pic.jpg')); ?>" alt="user" class="rounded" width="45"></div>
                                        </td>
                                        <td><?php echo e($blog->title); ?> </td>
                                        <td><?php echo e($blog->views); ?></td>
                                        <td><?php echo e($blog->likes); ?></td>
                                        <td><?php echo e($blog->dislikes); ?></td>
                                        <td><?php echo e($blog->shares); ?></td>
                                        <td><?php echo e($blog->created_at); ?></td>
                                        <td><?php echo e($blog->user->firstname); ?></td>
                                        <?php if($blog->status == "published"): ?>
                                        <td><span class="badge-dot badge-success mr-1"></span><?php echo e($blog->status); ?> </td>
                                        <?php else: ?>
                                        <td><span class="badge-dot badge-brand mr-1"></span><?php echo e($blog->status); ?> </td>
                                        <?php endif; ?>
                                        
                                        <td>
                                            <form method="POST" action="<?php echo e(route('blog.delete', ['blog' => $blog->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger"> Delete</button>
                                              </form>   
                                        </td>
                                        <td><a href="<?php echo e(route('blog.edit', ['id' => $blog->id])); ?>" class="btn btn-success">Edit</a></td>
                                    </tr>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <td >No Blogs posted</td>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00946ba7ba842207a1e069667fe21ffc)): ?>
<?php $attributes = $__attributesOriginal00946ba7ba842207a1e069667fe21ffc; ?>
<?php unset($__attributesOriginal00946ba7ba842207a1e069667fe21ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00946ba7ba842207a1e069667fe21ffc)): ?>
<?php $component = $__componentOriginal00946ba7ba842207a1e069667fe21ffc; ?>
<?php unset($__componentOriginal00946ba7ba842207a1e069667fe21ffc); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Documents\GitHub\pemu\resources\views/Admin/pages/viewblogs.blade.php ENDPATH**/ ?>