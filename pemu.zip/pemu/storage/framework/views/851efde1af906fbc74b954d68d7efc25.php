<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="farmers">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card-farmer">
                        <div class="card-header"><?php echo e(__('Add Farmer')); ?></div>

                        <div class="card-body">
                            <form method="POST" action="/pemu/farmer/store">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row">
                                    <label for="name"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Full Name')); ?></label>

                                    <div class="col-md-6">
                                        <input id="fullname" type="text"
                                            class="form-control <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fullname"
                                            value="<?php echo e(old('fullname')); ?>" required autocomplete="fullname" autofocus>

                                        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="gender"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Gender')); ?></label>

                                    <div class="col-md-6">

                                        <select class="form-control" name="gender" id="gender"
                                            style="background-color: white">
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                        </select>

                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="dob"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Date of Birth')); ?></label>

                                    <div class="col-md-6">

                                        <input id="dob" type="date"
                                            class="form-control <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dob"
                                            value="<?php echo e(old('dob')); ?>" required autocomplete="dob" autofocus>

                                        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="idnumber"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('ID Number')); ?></label>

                                    <div class="col-md-6">
                                        <input id="idnumber" type="text"
                                            class="form-control <?php $__errorArgs = ['idnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="idnumber"
                                            value="<?php echo e(old('idnumber')); ?>" required inputmode="numeric">

                                        <?php $__errorArgs = ['idnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>



                                </div>
                                <div class="form-group row">
                                    <label for="phonenumber"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>

                                    <div class="col-md-6">
                                        <input id="phonenumber" type="text"
                                            class="form-control <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="phonenumber" value="<?php echo e(old('phonenumber')); ?>" required
                                            placeholder="07" inputmode="numeric">

                                        <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="crops"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Crops (separate with commas)')); ?></label>

                                    <div class="col-md-6">
                                        <textarea class="form-control" name="crops"></textarea>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="area"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Area')); ?></label>

                                    <div class="col-md-6">
                                        <input id="area" type="text"
                                            class="form-control <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="area"
                                            value="<?php echo e(old('area')); ?>" required autocomplete="area" autofocus>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="operator"
                                        class="col-md-4 col-form-label text-md-right"><?php echo e(__('Farm Operator')); ?></label>

                                    <div class="col-md-6">
                                        <input id="operator" type="text"
                                            class="form-control <?php $__errorArgs = ['operator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="operator"
                                            value="<?php echo e(old('operator')); ?>" required autocomplete="operator" autofocus>
                                    </div>
                                </div>


                        </div>





                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register Farmer')); ?>

                                </button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Inputmask('9999 999999').mask(document.getElementById('phonenumber'));
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Inputmask('99999999').mask(document.getElementById('idnumber'));
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Alex\Documents\GitHub\pemu\resources\views/pages/farmer-create.blade.php ENDPATH**/ ?>