<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container emp-profile">
        <form method="post">
            <div class="row">
                <div class="col-md-4">
                    <div class="profile-img">
                        <img class="rounded-circle mr-3" style="max-width: 100px; max-height: 100px;" src="<?php echo e(asset('img/lgo.jpeg')); ?>" alt=""/>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="profile-head">
                        <h5>
                            <?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?>

                        </h5>
                        <h6>
                            <?php echo e(ucfirst(auth()->user()->role)); ?>

                        </h6>
                        <p class="proile-rating">Date Joined : <span><?php echo e(auth()->user()->created_at->diffForHumans()); ?></span></p>
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                            </li>
                            <?php if(auth()->user()->role == "admin"): ?>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Survey Report</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="row">
                        
                        <?php
                                 $userFilledSurvey = \App\Models\Survey::where('user_id', auth()->id())->exists();
                        ?>

                        <?php if(auth()->user()->role == "farmer"): ?>
                            <div class="col-md-6">
                                <?php if(!$userFilledSurvey): ?>
                                    <a href="<?php echo e(route('survey')); ?>" class="btn btn-rounded btn-success">
                                        <i class="fa fa-file-text" aria-hidden="true"></i> Take Our Survey
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                  
                    
                        
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="profile-work">
                        <!-- ... Your existing content ... -->
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="tab-content profile-tab" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Name</label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Email</label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e(auth()->user()->email); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Phone</label>
                                </div>
                                <div class="col-md-6">
                                    <p><?php echo e(auth()->user()->phone); ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Age</label>
                                </div>
                                <div class="col-md-6">
                                    <?php
                                            // Assuming 'dob' is the birthdate attribute of the user
                                            $birthdate = auth()->user()->dob;
                                            $age = now()->diffInYears($birthdate);
                                        ?>
                                   <p><?php echo e($age); ?></p>
                                </div>
                            </div>
                        </div>
                       
                        <div class="tab-pane fade" id="profile" role="tabpane2" aria-labelledby="profile-tab">
                           
                            <div class="row">
                                <div class="col-md-12">
                                    <?php if(!$userFilledSurvey): ?>
                                        <p>Please Take the survey to view report</p>
                                        <a href="<?php echo e(route('survey')); ?>" class="btn btn-rounded btn-success"><i class="fa fa-file-text" aria-hidden="true"></i> Take Our Survey</a>
                                        <?php else: ?>
                                       
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </form>           
    </div>

    <!-- Add Bootstrap JS and jQuery scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!-- Add script for tab switching -->
    <script>
        $(document).ready(function () {
            $('#myTab a').on('click', function (e) {
                e.preventDefault();
                $(this).tab('show');
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Documents\GitHub\pemu\resources\views/pages/profile-view.blade.php ENDPATH**/ ?>