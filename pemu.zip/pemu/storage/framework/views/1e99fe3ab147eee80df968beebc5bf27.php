<?php if (isset($component)) { $__componentOriginal00946ba7ba842207a1e069667fe21ffc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal00946ba7ba842207a1e069667fe21ffc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.adminlayout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid dashboard-content">
        <!-- ============================================================== -->
        <!-- pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="page-header">
                    <h2 class="pageheader-title">View <?php echo e($contact->name); ?>'s  Contact Form </h2>
                    <div class="page-breadcrumb">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">View</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end pageheader -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <h5 class="card-header"><?php echo e($contact->subject); ?></h5>
                    <div class="card-body">
                        <div class="media">
                          
                            <div class="media-body">
                                <h5><?php echo e($contact->name); ?></h5>
                                <p><?php echo e($contact->body); ?>.</p>
                                <form method="POST" action="<?php echo e(route('contact.delete', ['contact' => $contact->id])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger"> Delete</button>

                                    <a href="/pemu/contacts/view" class="btn btn-success">View Contacts</a>
                                  </form> 
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal00946ba7ba842207a1e069667fe21ffc)): ?>
<?php $attributes = $__attributesOriginal00946ba7ba842207a1e069667fe21ffc; ?>
<?php unset($__attributesOriginal00946ba7ba842207a1e069667fe21ffc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal00946ba7ba842207a1e069667fe21ffc)): ?>
<?php $component = $__componentOriginal00946ba7ba842207a1e069667fe21ffc; ?>
<?php unset($__componentOriginal00946ba7ba842207a1e069667fe21ffc); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Documents\GitHub\pemu\resources\views/Admin/pages/single-contact.blade.php ENDPATH**/ ?>