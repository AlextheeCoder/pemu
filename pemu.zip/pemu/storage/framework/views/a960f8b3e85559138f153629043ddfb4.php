<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <!-- Hero Start -->
     <div class="container-fluid bg-primary py-5 bg-hero mb-5">
        <div class="container py-5">
            <div class="row justify-content-start">
                <div class="col-lg-8 text-center text-lg-start">
                    <h1 class="display-1 text-white mb-md-4">Blogs</h1>
                    <a href="/" class="btn btn-primary py-md-3 px-md-5 me-3">Home</a>
                    <a href="/blogs" class="btn btn-secondary py-md-3 px-md-5">Blogs</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->
    
     <!-- Blog Start -->
     <div class="container py-5">
        <div class="row g-5">
            <!-- Blog list Start -->
            <div class="col-lg-8">
                <div class="row g-5">
                    <?php if (! (count($blogs) == 0)): ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($blog->status == 'published'): ?>
                            <article class="col-md-6">
                                <div class="blog-item position-relative overflow-hidden">
                                    <img class="img-fluid" style="height: 400px;" src="<?php echo e($blog->image ? asset('storage/' . $blog->image) : asset('img/blog-1.jpg')); ?>" alt="">
                                    <a class="blog-overlay" href="<?php echo e(route('blog.detail', ['slug' => $blog->slug])); ?>">
                                        <h4 class="text-white"><?php echo e($blog->title); ?></h4>
                                        <span class="text-white fw-bold"><?php echo e($blog->created_at->diffForHumans()); ?></span>
                                    </a>
                                </div>
                            </article>
                            <?php elseif($blog->status == 'staged'): ?>
                            <article class="col-md-6">
                                <div class="blog-item position-relative overflow-hidden">
                                    <p>No blogs posted</p>
                                </div>
                            </article>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <article class="col-md-6">
                        <div class="blog-item position-relative overflow-hidden">
                            <p>No blogs posted</p>
                        </div>
                    </article>
                <?php endif; ?>                


                    <div class="col-12">
                        <nav aria-label="Page navigation">
                            <?php echo e($blogs->links('pagination.custom')); ?>

                        </nav>
                    </div>
                    
                    
                </div>
            </div>
            <!-- Blog list End -->

            <!-- Sidebar Start -->
            <div class="col-lg-4">
                <!-- Search Form Start -->
                <div class="mb-5">
                    <form action="/blogs" method="GET">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control p-3" placeholder="Keyword" value="<?php echo e(request('search')); ?>">
                            <button type="submit" class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                        </div>
                    </form>
                </div>
                
                <!-- Search Form End -->

                <!-- Category Start -->
                <div class="mb-5">
                    <h2 class="mb-4">Categories</h2>
                    <div class="d-flex flex-column justify-content-start bg-primary p-4">
                        <?php if (! (count($popularCategories) == 0)): ?>
                        <?php $__currentLoopData = $popularCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="fs-5 fw-bold text-white mb-2" href="<?php echo e(route('blogs', ['category' => $category->category])); ?>">
                                <i class="bi bi-arrow-right me-2"></i><?php echo e($category->category); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                        <p>No Categories Yet</p>
                        <?php endif; ?>

                    </div>
                </div>
                <!-- Category End -->

                <!-- Recent Post Start -->
                <div class="mb-5">
                    <h2 class="mb-4">Recent Post</h2>
                    <div class="bg-primary p-4">
                        <?php if (! (count($latestblogs) == 0)): ?>
                        <?php $__currentLoopData = $latestblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="d-flex overflow-hidden mb-3">
                            <img class="img-fluid flex-shrink-0" src="<?php echo e($latestblog->image ? asset('storage/' . $latestblog->image) : asset('img/blog-1.jpg')); ?>" style="width: 75px;" alt="">
                            <a href="<?php echo e(route('blog.detail', ['slug' => $latestblog->slug])); ?>" class="d-flex align-items-center bg-white text-dark fs-5 fw-bold px-3 mb-0"> <?php echo e(strtok($latestblog->title, ' ')); ?> <?php echo e(strtok(' ')); ?> ...
                            </a>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <article class="d-flex overflow-hidden mb-3">
                            <p>No Blogs Posted Yet</p>
                        </article>
                        <?php endif; ?>
                       
                    </div>
                </div>
                <!-- Recent Post End -->

                <!-- Image Start -->
                
                <!-- Image End -->

                <!-- Tags Start -->
                <div class="mb-5">
                    <h2 class="mb-4">Tag Cloud</h2>
                    <div class="d-flex flex-wrap m-n1">
                        <?php if (! (count($latestblogs) == 0)): ?>
                            
                      
                        <?php $__currentLoopData = $popularTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $tagArray = explode(',', $tag->tags);
                            ?>
                            <?php $__currentLoopData = $tagArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('blogs', ['tag' => $singleTag])); ?>" class="btn btn-primary m-1"><?php echo e($singleTag); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <p>No tags yet</p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Tags End -->

                <!-- Plain Text Start -->
             
                <!-- Plain Text End -->
            </div>
            <!-- Sidebar End -->
        </div>
    </div>
    <!-- Blog End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\user\Documents\GitHub\pemu\resources\views/pages/blogs.blade.php ENDPATH**/ ?>